import streamlit as st

st.title('COVID-19 Dashboard')
st.write('This is a simple dashboard for visualizing COVID-19 data.')
